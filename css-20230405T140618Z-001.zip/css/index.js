// luas segitiga
function hitungLuas() {
    let alas = parseInt(document.getElementById("alas").value);
    let tinggi = parseInt(document.getElementById("tinggi").value);
    let hasil = 0.5 * alas * tinggi;
    document.getElementById("hasil luas segitiga").value = "Luas segitiga: " + hasil;
}

// keliling segitiga
function hitungKeliling() {
    let sisi1 = parseInt(document.getElementById("sisi1").value);
    let sisi2 = parseInt(document.getElementById("sisi2").value);
    let sisi3 = parseInt(document.getElementById("sisi3").value);
    let hasil = sisi1 + sisi2 + sisi3;
    document.getElementById("hasil keliling segitiga").value = "Keliling segitiga: " + hasil;
}

// luas jajargenjang
function hitungluas() {
    const base = document.getElementById("base").value;
    const height = document.getElementById("height").value;
    const luas = base * height;
    alert("Luas jajargenjang adalah " + luas);
}

function hitungkeliling() {
    var alas = parseInt(document.getElementById("alas").value);
    var miring = parseInt(document.getElementById("miring").value);
    console.log(alas, miring); // Tambahkan baris ini untuk memeriksa nilai variabel
    var hasil = 2 * ( 24 + 12 );
    document.getElementById("hasil").value = "Keliling Jajargenjang: " + hasil;
}

